/*----------------------------
Created by :	 CAN
File name :		 slist.cpp

---------------------------------*/

#include<iostream>
#include"slist.h"
#include "malloc.h"
using namespace std;


extern slist * slist_append(slist * list, void * data){
    slist *walk = list ;
    slist *new_Item = (slist *)malloc(sizeof(slist));
    if(!new_Item){
        perror("Cannot allocate the mem\n");
        return new_Item;
    }
    else{
    new_Item->data=data;
    new_Item->next=NULL;
    if(walk){
    while(walk){
        if(walk->next==NULL){
            walk->next=new_Item;
            break;
        }
        walk=walk->next;
    }
    return list;
    }
    else{
        return new_Item;
    }
    }
}
//----------------count item function--------------------------------
extern int count_item(slist * list){
    slist *walk=list;
    int i=0;
    while(walk){
        //cout<<"cout item"<<endl;
    i++;
        walk=walk->next;
    }
    return i;

}


extern void  out_put_list_data(slist *list, void (*out)(void*data)){
    slist *walk =list;
    int i=0;
    if(walk){
        while(walk){
            out(walk->data);
            walk=walk->next;
            i++;
        }
    }
    else{
    cout<<"danh sach rong ! "<<endl;
    }
}

extern slist  *slist_find( slist *list, void * data,bool (*compare_func)(void * ,void *)){
    slist *walk = list;
    if(walk){
        int i=0;
        while(walk){
            i++;
            if(compare_func(data,walk->data)){
                //walk->next=NULL;
            //outList=walk->next;
            return walk;
            break;
            }
            walk=walk->next;
        }if(walk==NULL){
        cout<<"khong tim thay sinh vien "<<endl;
        return NULL;
        }
    }
    else{
        perror("danh sach rong!\n");
        return NULL;
    }
}

extern int  slist_find_index( slist *list, void * data,bool (*compare_func)(void * ,void *)){
    slist *walk = list;
    int index=0;
    if(walk){
        while(walk){
            index++;
            if(compare_func(data,walk->data)){
            return index;
            break;
            }
            walk=walk->next;
        }if(walk==NULL){
        cout<<"khong tim thay sinh vien "<<endl;
        return 0;
        }
    }
    else{
        perror("danh sach rong!\n");
        return 0;
    }

}



//---------------remove-by-index function define -----------------------
extern slist * slist_remove_by_index(slist* list,int index,void (*release_data_function)(void *)){
    slist * walk=list,*outList=NULL,*pre_walk=NULL;
    if(walk){
        outList=walk->next;
        if(index==1){
            cout<<"index"<<endl;
            if(release_data_function){
            release_data_function(walk->data);
            cout<<"release_data_function done!"<<endl;
            free(walk);
            cout<<"free done!"<<endl;
            }
            return outList;
        }
        if(index==count_item(list)){
            cout<<"count_item(list)="<<count_item(list)<<endl;
            if(release_data_function){
                while(walk->next){
                    pre_walk=walk;
                    walk =walk->next;
                }
                pre_walk->next=NULL;
            release_data_function(walk->data);
            cout<<"release_data_function done!"<<endl;
            free(walk);
            cout<<"free done!"<<endl;
            }
            return list;
        }
        int i=0;
        while(walk){
            i++;
            if(release_data_function){
                //cout<<"release_data_function"<<endl;
            if(i==index){
                cout<<"right remove item condition"<<endl;
                pre_walk->next=walk->next;
            release_data_function(walk->data);
            cout<<"release_data_function done!"<<endl;
            free(walk);
            cout<<"free done!"<<endl;
            return list;
            break;
           }}
            pre_walk=walk;
            walk=walk->next;
        }
        if(walk==NULL){
        cout<<"danh sach khong co phan tu can xoa "<<endl;
        return list;
        }

    }else{
    cout<<"danh sach rong"<<endl;
    return outList;
    }
}

extern slist * slist_remove_by_id(slist* list,void * data,bool (*compare_func)(void * ,void *),void (*release_data_function)(void *)){
    slist * walk= list;
    while(walk){
        if(compare_func(data,walk->data)){


        }
        walk=walk->next;
    }
    return NULL;
    }


extern void slistSaveFile(slist*list, ofstream &out, void (*save)(ofstream &out,void *data)){
    slist * walk = list;
    while(walk){
    save(out,walk->data);
    walk=walk->next;
    }
}

extern bool slist_check_item_exist(slist *list, void * data, bool(*compare_func)(void *, void *)){
    slist * walk=list;
    while(walk){
        if(compare_func(data,walk->data)){ return true;break;}
        walk=walk->next;
    }
    return false;
}
