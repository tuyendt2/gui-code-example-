/*----------------------------
Created by :	 CAN
File name :		 slist.h

---------------------------------*/
#ifndef SLIST_H
#define SLIST_H

#include<iostream>
#include <typeinfo>
#include <fstream>
using namespace std;
// --------------------function pointer declare--------------------------
 #define FORCE_DATA_TYPE(type,item) (type*)(item->data)
 typedef bool (*compare_func)(void * ,void *);
 typedef void (*call_back)(int index,void *data_1,void*data_2);
 typedef void (*release_data_function)(void *);


//----------------slist type define---------------------
// khai b�o node trong list
typedef struct slist{
    void *data;  /**< the pointer to data */
    struct slist * next;  /**< the pointer to next element of list */
}slist;

//----------add node function----------------------------

extern slist * slist_append(slist * list, void * data);
//----------------count item function--------------------------------
extern int count_item(slist * list);

extern void  out_put_list_data(slist *list, void (*out)(void*data));

extern slist  *slist_find( slist *list, void * data,bool (*compare_func)(void * ,void *));

extern int  slist_find_index( slist *list, void * data,bool (*compare_func)(void * ,void *));

extern slist * slist_remove_by_index(slist* list,int index,void (*release_data_function)(void *));

extern slist * slist_remove_by_id(slist* list,int id,bool (*compare_func)(void * ,void *),void (*release_data_function)(void *));

extern void slistSaveFile(slist*list, ofstream &out, void (*save)(ofstream &out,void *data));

extern bool slist_check_item_exist(slist *list, void * data, bool(*compare_func)(void *, void *));
#endif
