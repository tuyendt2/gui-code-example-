#ifndef MYLIB_H
#define MYLIB_H

#include <iostream>
#include <string.h>
#include <fstream>
#include "slist.h"

using namespace std;

typedef struct index_arr{
    char ** arr;
    int index;
} index_arr ;
typedef struct database{
    slist * Lmessage;
    slist *Lsignal;
}database;
extern bool compare_arr(char *a,char *b);
extern index_arr split(char str[]);
extern void show_sig(void *data);
extern void output(void *data);
extern void out_signal(void *data);
extern void saveFile_signal(ofstream &out,void *data);
extern void saveFile(ofstream &out,void *data);
extern database loadDatabase(ifstream &in);
extern bool id_compare(void * data1, void * data2);
extern void release_msg(void *data);
extern bool compare_signal(void * sig1,void * sig2);
#endif // !MYLIB_H
