#include "QtCore"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mydialog.h"
#include "about.h"
#include <iostream>
#include <fstream>
#include<stdio.h>
#include <string>
#include "msg.h"
#include <stdlib.h>
#include "slist.h"
#include "msg_sgn.h"
#include "mylib.h"
using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    QWidget *mainlayout =  new QWidget(this);
    ifstream in;
    in.open("C:/Users/HCD-Fresher295/Desktop/UI/database/database/database/database/Can.dbc");
    database rs = loadDatabase(in);
    slist *mess_list= rs.Lmessage;
    slist *signal_list=rs.Lsignal;
    treeView = new QTreeView(this);
    setCentralWidget(treeView);
    model = new QStandardItemModel;
    QStandardItem *rootItem= model->invisibleRootItem();
    QStandardItem *mess = new QStandardItem("Messages");
    QStandardItem *signal = new QStandardItem("Signals");
    rootItem->appendRow(mess);
    rootItem->appendRow(signal);
    slist * walk = mess_list->next;
    QStandardItem *item;
    while(walk){
        msg * message = (msg*) walk->data;
        item = new QStandardItem((QString)message->getName().c_str());
        mess->appendRow(item);
        slist * msg_sgn_walk = ((msg*)walk->data)->getSgnList();
        slist * mWalk = msg_sgn_walk;
        QStandardItem * msg_sgn_item;
        while(mWalk){
            msg_sgn * messagedSig = (msg_sgn*)mWalk->data;
            msg_sgn_item = new QStandardItem((QString)messagedSig->getName().c_str());
            item->appendRow(msg_sgn_item);
            mWalk= mWalk->next;
        }
        walk=walk->next;
    }
    slist* Swalk = signal_list;
    QStandardItem *Sitem;
    while(Swalk){
        sgn * sig = (sgn*)Swalk->data;
        Sitem = new QStandardItem((QString)sig->getName().c_str());
        signal->appendRow(Sitem);
        Swalk=Swalk->next;
    }

// qtablewidget
    QStringList m1_TableHeader;
    QTableWidget * tableWidget = new QTableWidget(10, 8, 0);
    m1_TableHeader<<"Name"<<"ID"<<"ID-Format"<<"DLC[Byte]"<<"Tx Method"<<"Cycle Time"<<"Transmitter"<<"Comment";
    tableWidget->setHorizontalHeaderLabels(m1_TableHeader);
    QStringList m1_TableHeader2;
    QTableWidget * tableWidget2 = new QTableWidget(10, 8, 0);
    m1_TableHeader2<<"Name"<<"Length[Bit]"<<"Byte Order"<<"Value Type"<<"Initial Value"<<"Factor"<<"Offset"<<"Minimum"<<"Maximum"<<"Unit"<<"Value Table"<<"Comment";
    tableWidget2->setHorizontalHeaderLabels(m1_TableHeader);
    stackedWidget = new QStackedWidget(this);
    stackedWidget->addWidget(tableWidget);
    stackedWidget->addWidget(tableWidget2);
    QHBoxLayout *layout = new QHBoxLayout(this);
    layout->addWidget(treeView,2);
    layout->addWidget(stackedWidget,7);

    mainlayout->setLayout(layout);
    setCentralWidget(mainlayout);
    treeView->setModel(model);
    connect(treeView, SIGNAL(clicked(QModelIndex)), stackedwidget,  SLOT(setCurrentIndex(int)));
    //treeView->expandAll();
}




MainWindow::~MainWindow()
{

}
