#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>

QT_BEGIN_NAMESPACE // QT_BEGIN_NAMESPACE / QT_END_NAMESPACE are not needed in Qt user code
class QTreeView; //forward declarations
class QStandardItemModel;
class QStandardItem;
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    QTreeView *treeView;
    QStandardItemModel *standardModel;
    QList<QStandardItem *> prepareRow( const QString &first,
                                       const QString &second,
                                       const QString &third );
public:
    MainWindow(QWidget *parent = 0);
};

#endif // MAINWINDOW_H
