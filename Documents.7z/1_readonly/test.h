#ifndef TEST_H
#define TEST_H
#include <QString>

class test
{
public:
    test(){};
    void setFirst(int first){
        this->first=first;
    }
    void setSecond(QString second){
        this->second=second;
    }
    int getFirst(){
        return this->first;
    }
    QString getSec(){
        return this->second;
    }

private:
    int first;
    QString second;
};

#endif // TEST_H
