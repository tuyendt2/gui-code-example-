#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTreeView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QListView>
#include <QLayout>
const int ROWS = 2;
const int COLUMNS = 3;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
  // QWidget *widget = new QWidget;
    treeView = new QTreeView(this);
    setCentralWidget(treeView);
   // QHBoxLayout *Hlayout = new QHBoxLayout();
    standardModel = new QStandardItemModel ;
    //QList<QStandardItem *> preparedRow =prepareRow("first", "second", "third");
    QList<QStandardItem *> preparedRow =prepareRow2(QString("a,b,c").split(","));
    QStandardItem *item = standardModel->invisibleRootItem();
    // adding a row to the invisible root item produces a root element
    item->appendRow(preparedRow);

    QList<QStandardItem *> secondRow =prepareRow("111", "222", "333");
    // adding a row to an item starts a subtree
    preparedRow.first()->appendRow(secondRow);

   treeView->setModel(standardModel);
    treeView->expandAll();
   // Hlayout->addWidget(treeView);
   // widget->setLayout(Hlayout);
}
QList<QStandardItem *> MainWindow::prepareRow(const QString &first,
                                                const QString &second,
                                                const QString &third)
{
    QList<QStandardItem *> rowItems;
    rowItems << new QStandardItem(first);
    rowItems << new QStandardItem(second);
    rowItems << new QStandardItem(third);
    return rowItems;
}
QList<QStandardItem *> MainWindow::prepareRow2(const QStringList Stringlist){
QList<QStandardItem *> rowItems;
for(int i=0;i<Stringlist.count();i++){
    rowItems << new QStandardItem(Stringlist.at(i));
}
return rowItems;
}
